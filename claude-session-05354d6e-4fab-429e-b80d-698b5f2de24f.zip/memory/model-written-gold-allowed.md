---
name: model-written-gold-allowed
description: "SN92 training data may use model-written / classifier-assigned gold labels (e.g. WildGuardMix GPT-4 labels, OpenAlex subfields); the user's earlier \"no model-written gold\" rule was lifted 2026-10-29"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 05354d6e-4fab-429e-b80d-698b5f2de24f
  modified: 2026-10-29T06:22:19.080Z
---

The user's earlier rule "No model-written gold labels. Gold comes from code or from the source's structured field" was lifted on 2026-10-29 ("an incorrectly defined custom rule").

**Why:** the subnet's code and docs never forbid it. FORMAT.md / DEV-CARD.md only say the subnet's own items contain no model-written content. No code in tools/ or src/reax_subnet checks how training gold was made. The user only wants rules that the subnet's own code/docs back.

**How to apply:** don't exclude or flag training rows because their labels come from a model or classifier (t2 wildguard, arxiv_category). Mention label quality only as a measured risk (e.g. validator wildguard uses human labels), not as a rule violation. Same principle as [[dev-sources-allowed]].
