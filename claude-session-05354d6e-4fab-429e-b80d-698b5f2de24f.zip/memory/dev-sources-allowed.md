---
name: dev-sources-allowed
description: "SN92 dev set may be trained on — both the 300 dev items (eval-v5/devset-v1) and the dev sources (Python PEPs, RFC index, NHTSA); user's earlier bans lifted 2026-10-29"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 05354d6e-4fab-429e-b80d-698b5f2de24f
  modified: 2026-10-29T06:30:27.505Z
---

On 2026-10-29 the user lifted two of their own earlier rules: "never use the dev sources (NHTSA recalls, Python PEPs, the RFC index)" and "never train on eval-v5/devset-v1". The dev items "must" be used ("this is important").

**Why:** the subnet's code and docs don't forbid either. FORMAT.md only advises against training on the dev items' exact content; the dev set has weight 0 live; the gap check uses the sealed pool's own public tiers, not dev. The user's principle: a rule that the subnet doesn't back is an incorrectly defined rule.

**How to apply:** the code guard was changed on 2026-10-29 (tools/train_generalist/data.py FORBIDDEN_TRAIN now only blocks data/generalist/heldout; select_take.py likewise). Include dev rows in training sets. Dev items that are trained on are no longer a check: score only dev items left out of training, report dev also without python_pep_status / rfc_status / nhtsa_recall_component, and lean on other held-out data (t2 MIX-test/check) and the validator. Still blocked: data/generalist/heldout and the 3 remaining held-out domains (EPA enforcement, visa fee waivers, transit fares). Related: [[model-written-gold-allowed]], [[sn92-hotkey]].
