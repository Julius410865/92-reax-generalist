---
name: sn92-hotkey
description: "The user's SN92 generalist submission hotkey address (public ss58) and which wallet file it is"
metadata:
  node_type: memory
  type: project
  originSessionId: 05354d6e-4fab-429e-b80d-698b5f2de24f
  modified: 2026-10-28T15:12:10.709Z
---

Submission hotkey for the SN92 generalist entry: `5EXSBXEnKznf4hArQ3DmbZbyaaETBeeJ2MVKWvJqEDuRxbge` (given by the user 2026-10-28). It is wallet `rabi`, hotkey `rabi-h2` under `~/.bittensor/wallets/rabi/hotkeys/`.

**Why:** export.py needs `--hotkey <ss58>` for `reax-specialist.json`; the commitment is made from this hotkey.

**How to apply:** use this address for exports; only the public ss58 field may be read from wallet files, never key material. The user forbids a coldkey on this machine; on 2026-10-28 a `coldkey` file was found in `~/.bittensor/wallets/rabi/` (dated 2026-10-27 17:26) and reported to the user, not touched.
