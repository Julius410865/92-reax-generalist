<!--
**Note:** When your KEP is complete, all of these comment blocks should be removed.

To get started with this template:

- [ ] **Pick a hosting SIG.**
  Make sure that the problem space is something the SIG is interested in taking
  up. KEPs should not be checked in without a sponsoring SIG.
- [ ] **Create an issue in kubernetes/enhancements**
  When filing an enhancement tracking issue, please make sure to complete all
  fields in that template. One of the fields asks for a link to the KEP. You
  can leave that blank until this KEP is filed, and then go back to the
  enhancement and add the link.
- [ ] **Make a copy of this template directory.**
  Copy this template into the owning SIG's directory and name it
  `NNNN-short-descriptive-title`, where `NNNN` is the issue number (with no
  leading-zero padding) assigned to your enhancement above.
- [ ] **Fill out as much of the kep.yaml file as you can.**
  At minimum, you should fill in the "Title", "Authors", "Owning-sig",
  "Status", and date-related fields.
- [ ] **Fill out this file as best you can.**
  At minimum, you should fill in the "Summary" and "Motivation" sections.
  These should be easy if you've preflighted the idea of the KEP with the
  appropriate SIG(s).
- [ ] **Create a PR for this KEP.**
  Assign it to people in the SIG who are sponsoring this process.
- [ ] **Merge early and iterate.**
  Avoid getting hung up on specific details and instead aim to get the goals of
  the KEP clarified and merged quickly. The best way to do this is to just
  start with the high-level sections and fill out details incrementally in
  subsequent PRs.

Just because a KEP is merged does not mean it is complete or approved. Any KEP
marked as `provisional` is a working document and subject to change. You can
denote sections that are under active debate as follows:

```
<<[UNRESOLVED optional short context or usernames ]>>
Stuff that is being argued.
<<[/UNRESOLVED]>>
```

When editing KEPS, aim for tightly-scoped, single-topic PRs to keep discussions
focused. If you disagree with what is already in a document, open a new PR
with suggested changes.

One KEP corresponds to one "feature" or "enhancement" for its whole lifecycle.
You do not need a new KEP to move from beta to GA, for example. If
new details emerge that belong in the KEP, edit the KEP. Once a feature has become
"implemented", major changes should get new KEPs.

The canonical place for the latest set of instructions (and the likely source
of this file) is [here](/keps/NNNN-kep-template/README.md).

**Note:** Any PRs to move a KEP to `implementable`, or significant changes once
it is marked `implementable`, must be approved by each of the KEP approvers.
If none of those approvers are still appropriate, then changes to that list
should be approved by the remaining approvers and/or the owning SIG (or
SIG Architecture for cross-cutting KEPs).
-->
# KEP-2599: minReadySeconds for StatefulSets

<!--
This is the title of your KEP. Keep it short, simple, and descriptive. A good
title can help communicate what the KEP is and should be considered as part of
any review.
-->

<!--
A table of contents is helpful for quickly jumping to sections of a KEP and for
highlighting any additional information provided beyond the standard KEP
template.

Ensure the TOC is wrapped with
  <code>&lt;!-- toc --&rt;&lt;!-- /toc --&rt;</code>
tags, and then generate with `hack/update-toc.sh`.
-->

<!-- toc -->
- [Release Signoff Checklist](#release-signoff-checklist)
- [Summary](#summary)
- [Motivation](#motivation)
  - [Goals](#goals)
  - [Non-Goals](#non-goals)
- [Proposal](#proposal)
  - [User Stories (Optional)](#user-stories-optional)
    - [Story 1](#story-1)
    - [Story 2](#story-2)
  - [Notes/Constraints/Caveats (Optional)](#notesconstraintscaveats-optional)
  - [Risks and Mitigations](#risks-and-mitigations)
- [Design Details](#design-details)
  - [StatefulSet](#statefulset)
  - [Test Plan](#test-plan)
    - [Prerequisite testing updates](#prerequisite-testing-updates)
      - [Unit tests](#unit-tests)
      - [Integration tests](#integration-tests)
      - [e2e tests](#e2e-tests)
  - [Graduation Criteria](#graduation-criteria)
    - [Alpha](#alpha)
    - [Alpha -&gt; Beta Graduation](#alpha---beta-graduation)
    - [Beta -&gt; GA Graduation](#beta---ga-graduation)
  - [Upgrade / Downgrade Strategy](#upgrade--downgrade-strategy)
  - [Version Skew Strategy](#version-skew-strategy)
- [Production Readiness Review Questionnaire](#production-readiness-review-questionnaire)
  - [Feature Enablement and Rollback](#feature-enablement-and-rollback)
  - [Rollout, Upgrade and Rollback Planning](#rollout-upgrade-and-rollback-planning)
  - [Monitoring Requirements](#monitoring-requirements)
  - [Dependencies](#dependencies)
  - [Scalability](#scalability)
  - [Troubleshooting](#troubleshooting)
- [Implementation History](#implementation-history)
- [Drawbacks](#drawbacks)
- [Alternatives](#alternatives)
- [Infrastructure Needed (Optional)](#infrastructure-needed-optional)
<!-- /toc -->

## Release Signoff Checklist

<!--
**ACTION REQUIRED:** In order to merge code into a release, there must be an
issue in [kubernetes/enhancements] referencing this KEP and targeting a release
milestone **before the [Enhancement Freeze](https://git.k8s.io/sig-release/releases)
of the targeted release**.

For enhancements that make changes to code or processes/procedures in core
Kubernetes—i.e., [kubernetes/kubernetes], we require the following Release
Signoff checklist to be completed.

Check these off as they are completed for the Release Team to track. These
checklist items _must_ be updated for the enhancement to be released.
-->

Items marked with (R) are required *prior to targeting to a milestone / release*.

- [ ] (R) Enhancement issue in release milestone, which links to KEP dir in [kubernetes/enhancements] (not the initial KEP PR)
- [ ] (R) KEP approvers have approved the KEP status as `implementable`
- [ ] (R) Design details are appropriately documented
- [ ] (R) Test plan is in place, giving consideration to SIG Architecture and SIG Testing input (including test refactors)
- [ ] (R) Graduation criteria is in place
- [ ] (R) Production readiness review completed
- [ ] (R) Production readiness review approved
- [ ] "Implementation History" section is up-to-date for milestone
- [ ] User-facing documentation has been created in [kubernetes/website], for publication to [kubernetes.io]
- [ ] Supporting documentation—e.g., additional design documents, links to mailing list discussions/SIG meetings, relevant PRs/issues, release notes

<!--
**Note:** This checklist is iterative and should be reviewed and updated every time this enhancement is being considered for a milestone.
-->

[kubernetes.io]: https://kubernetes.io/
[kubernetes/enhancements]: https://git.k8s.io/enhancements
[kubernetes/kubernetes]: https://git.k8s.io/kubernetes
[kubernetes/website]: https://git.k8s.io/website

## Summary

The main goal of this enhancement is to introduce minReadySeconds as an 
optional field to StatefulSets. 

## Motivation

minReadySeconds specifies the minimum number of seconds for which a newly 
created Pod should be ready without any of its containers crashing, for it 
to be considered available. This defaults to 0 (the pod will be considered 
available as soon as it is ready).

minReadySeconds is already available as an optional field for Deployments,
DaemonSets, ReplicasSets and Replication Controllers. Enabling this option 
helps in bringing StatefulSets on par with other workload controllers.

Note: The important point to understand is when will a pod be considered
`Ready` which might depend on the container probes configured. For example,
for a pod with single container having a readiness check with `initialDelaySeconds`, 
for the pod to considered `Available` it has to be implicitly `Ready` for 
`initialDelaySeconds`+`minReadySeconds`.

### Goals

StatefulSet Controller honoring minReadySeconds and mark Pod ready only if Pod 
is available for given time mentioned in minReadySeconds.

### Non-Goals

Moving minReadySeconds to Pod Spec is beyond the scope of this KEP 
because of following reasons:
- The effort to change pod spec would be large. While this also helps other controllers like
  endpoint controller to look at the pod status and propagate, the main goal of this KEP is to introduce
  minReadySeconds field to StatefulSet spec to bring consistency.
- Currently our workload controllers are inconsistent and we prioritize consistency of experience. 
- StatefulSets are just different enough from daemonsets and deployments that real world use of minReadySeconds 
  for stateful sets might influence any future design or point in a more appropriate direction.

More information about the discussion can be found [here](https://github.com/kubernetes/kubernetes/issues/65098)
and why we are going ahead with this approach as there was consensus to bring consistency of experience.


## Proposal

StatefulSet spec should be expanded with an optional field called 
minReadySeconds. To reflect the StatefulSet pods that honored minReadySeconds,
an additional field called `AvailableReplicas` will also be added to
StatefulSet status.

### User Stories (Optional)

#### Story 1
As a Kubernetes user, I want to ensure that my StatefulSet Pods have the 
desired state ready before they start serving requests. Some applications 
should only be considered as available only when the state transfer has 
happened properly.

#### Story 2
As a Kubernetes user, I want to leverage StatefulSet's minReadySeconds behind
service loadbalancers in clouds. This is to prevent killing pods in rotation
before new pods show up.

### Notes/Constraints/Caveats (Optional)

### Risks and Mitigations

We are proposing a new field called `minReadySeconds` whose default value will 
be 0. In this mode, StatefulSet will behave exactly like its current behavior.
Its possible we introduce a bug in the implementation. The bug can cause the
 
- Pod to be marked as ready too soon. This means that the end user may think 
that their workload is available to be used but in reality, the workload is 
not available yet
- Pod to be marked as ready too late. This means that the end user may think
that their workload is not available yet but in reality, the workload is 
ready to be used.


The mitigation currently is that is disabled by default in Alpha phase behind 
a feature gate for people to try out and give feedback. In Beta phase when 
its enabled by default, people will only see issues or bugs when `minReadySeconds` 
is set to something greater than 0. Since people would have tried this feature 
in Alpha, we would have had time to fix issues.

## Design Details

### StatefulSet

```go
type StatefulSetSpec struct {
	// Minimum number of seconds for which a newly created pod should be ready
	// without any of its container crashing, for it to be considered available.
	// Defaults to 0 (pod will be considered available as soon as it is ready)
	// This is an alpha field and requires enabling StatefulSetMinReadySeconds feature gate.
	// +optional
	MinReadySeconds int32
}

type StatefulSetStatus struct {
	// Total number of available pods (ready for at least minReadySeconds) targeted by this statefulset.
	// This is an alpha field and requires enabling StatefulSetMinReadySeconds feature gate.
	// +optional
	AvailabileReplicas int32
}
```


### Test Plan

Unit, integration and E2E tests cover the existing StatefulSet mechanics.
Additionally, unit and integration tests will be added to cover the
API validation, behavioral change of StatefulSet with feature gate enabled and disabled.

#### Prerequisite testing updates

[x] I/we understand the owners of the involved components may require updates to existing tests to make this code solid enough prior to committing the changes necessary to implement this enhancement.

##### Unit tests

```
`k8s.io/kubernetes/pkg/apis/apps/validation`                       `06/07/2022`:    `90.6% of statements` `The tests added for the current feature in this package touches the statefulSet Spec and Status fields. No new tests are needed for promotion to GA`
`k8s.io/kubernetes/pkg/apis/apps/validation/validation.go:93`:	   `06/07/2022`:		`93.1% of statements`
`k8s.io/kubernetes/pkg/apis/apps/validation/validation.go:162`:	   `06/07/2022`:		`100% of statements`
`k8s.io/kubernetes/pkg/apis/apps/validation/validation.go:169`:	   `06/07/2022`:		`94.1% of statements`
`k8s.io/kubernetes/pkg/apis/apps/validation/validation.go:199`:	   `06/07/2022`:		`100% of statements`
`k8s.io/kubernetes/pkg/controller/statefulset`:                    `06/07/2022`:    `85.5% of statements` `The tests added for the current feature in this package touches the statefulSet upgrade strategies. No new tests are needed for promotion to GA`
`k8s.io/kubernetes/pkg/registry/apps/statefulset`:                 `06/07/2022`:    `76.7% of statements` `The tests added for the current feature in this package makes sure that the kubernetes version upgrades won't have any impact on the new fields to the statefulset api when persisting to etcd. No new tests are needed for promotion to GA`
`k8s.io/kubernetes/pkg/registry/apps/statefulset/strategy.go:95`:	 `06/07/2022`:	  `100.0% of statements`
`k8s.io/kubernetes/pkg/registry/apps/statefulset/strategy.go:139`: `06/07/2022`:	  `100.0% of statements`
`k8s.io/kubernetes/pkg/registry/apps/statefulset/strategy.go:223`: `06/07/2022`:	  `100.0% of statements`
`k8s.io/kubernetes/pkg/registry/apps/statefulset/strategy.go:118`: `06/07/2022`:	  `100.0% of statements`
```

##### Integration tests

Added integration tests to test availabile replicas when minReadySeconds is set on the statefulset spec.

k8s.io/kubernetes/test/integration/statefulset.TestStatefulSetAvailable: [test grid](https://testgrid.k8s.io/sig-release-master-blocking#integration-master)

##### e2e tests

Following e2e tests are added to statefulsets.
- StatefulSet MinReadySeconds should be honored when enabled: [test grid](https://storage.googleapis.com/k8s-triage/index.html?sig=apps&test=statefulset)
- StatefulSet AvailableReplicas should get updated accordingly when MinReadySeconds is enabled: [test grid](https://storage.googleapis.com/k8s-triage/index.html?sig=apps&test=statefulset)

### Graduation Criteria

#### Alpha
- Complete feature behind a featuregate
- Have proper unit and integration tests

#### Alpha -> Beta Graduation
- Gather feedback from end users
- Tests are in Testgrid and linked in KEP

#### Beta -> GA Graduation
- 2 examples of end users using this field
  - The latest version of [OpenShift](https://github.com/openshift/cluster-monitoring-operator/blob/3ff846fbf36f68ff9aa2145b86ba5fc485398a6b/manifests/0000_50_cluster-monitoring-operator_00_0thanosruler-custom-resource-definition.yaml#L3607) is using this field for cluster monitoring operator
  - [Prometheus-operator alert manager](https://github.com/prometheus-operator/prometheus-operator/blob/e45574036f4282c519b64f458d296ca82f455a45/example/prometheus-operator-crd/monitoring.coreos.com_alertmanagers.yaml#L3549) uses this field
  - Other users requesting for this feature can be found in the [github issue](https://github.com/kubernetes/kubernetes/issues/65098)

<!--
**Note:** *Not required until targeted at a release.*

Define graduation milestones.



#### Alpha -> Beta Graduation

- Gather feedback from developers and surveys
- Complete features A, B, C
- Tests are in Testgrid and linked in KEP

#### Beta -> GA Graduation

- N examples of real-world usage
- N installs
- More rigorous forms of testing—e.g., downgrade tests and scalability tests
- Allowing time for feedback

**Note:** Generally we also wait at least two releases between beta and
GA/stable, because there's no opportunity for user feedback, or even bug reports,
in back-to-back releases.

#### Removing a Deprecated Flag

- Announce deprecation and support policy of the existing flag
- Two versions passed since introducing the functionality that deprecates the flag (to address version skew)
- Address feedback on usage/changed behavior, provided on GitHub issues
- Deprecate the flag

**For non-optional features moving to GA, the graduation criteria must include 
[conformance tests].**

[conformance tests]: https://git.k8s.io/community/contributors/devel/sig-architecture/conformance-tests.md
-->

### Upgrade / Downgrade Strategy
- Upgrades
 When upgrading from a release without this feature, to a release with 
 `minReadySeconds`, we will set `minReadySeconds` to 0. This would give users 
 the same default behavior. The default value of `AvailableReplicas` would
 be value of existing field in Status sub-resource called `ReadyReplicas`
- Downgrades
 When downgrading from a release with this feature, to a release without 
 `minReadySeconds`, there are two cases
  - If `minReadySeconds` is greater than 0 -- the StatefulSet controller wouldn't honor 
    `minReadySeconds` which is expected. The `AvailableReplicas` will be set to `ReadyReplicas`
    by StatefulSet controller
  - If `minReadySeconds` is equal to 0 -- in this case user won't see any 
    difference in behavior. The `AvailableReplicas` will be set to `ReadyReplicas`
    by StatefulSet controller

We will ensure that the minReadySeconds field is properly validated
before persisting. The validation includes checking for positive number
or 0 for the minReadySeconds field.

### Version Skew Strategy

If the feature gate is enabled, the controller manager updates the 
`AvailableReplicas` to reflect the pods that have been available for 
minReadySeconds as mentioned earlier, if not the controller manager 
runs as is. This feature has no node runtime implications.

## Production Readiness Review Questionnaire

<!--

Production readiness reviews are intended to ensure that features merging into
Kubernetes are observable, scalable and supportable; can be safely operated in
production environments, and can be disabled or rolled back in the event they
cause increased failures in production. See more in the PRR KEP at
https://git.k8s.io/enhancements/keps/sig-architecture/1194-prod-readiness.

The production readiness review questionnaire must be completed and approved
for the KEP to move to `implementable` status and be included in the release.

In some cases, the questions below should also have answers in `kep.yaml`. This
is to enable automation to verify the presence of the review, and to reduce review
burden and latency.

The KEP must have a approver from the
[`prod-readiness-approvers`](http://git.k8s.io/enhancements/OWNERS_ALIASES)
team. Please reach out on the
[#prod-readiness](https://kubernetes.slack.com/archives/CPNHUMN74) channel if
you need any help or guidance.
-->

### Feature Enablement and Rollback

###### How can this feature be enabled / disabled in a live cluster?

<!--
Pick one of these and delete the rest.
-->

- [x] Feature gate (also fill in values in `kep.yaml`)
  - Feature gate name: StatefulSetMinReadySeconds
  - Components depending on the feature gate:
    - kube-controller-manager
    - kube-apiserver

###### Does enabling the feature change any default behavior?

No, StatefulSet needs to have `.spec.minReadySeconds` explicitly set

###### Can the feature be disabled once it has been enabled (i.e. can we roll back the enablement)?

Yes. Using the featuregate is the only way to enable/disable this feature

###### What happens if we reenable the feature if it was previously rolled back?

The StatefulSet controller starts respecting the `minReadySeconds` again 

###### Are there any tests for feature enablement/disablement?

Yes, unit and integration tests for feature on, off. Please look at test plan [section](#test-plan)

### Rollout, Upgrade and Rollback Planning

<!--
This section must be completed when targeting beta to a release.
-->

###### How can a rollout fail? Can it impact already running workloads?

<!--
Try to be as paranoid as possible - e.g., what if some components will restart
mid-rollout?
-->
It shouldn't impact already running workloads. This is an opt-in feature since 
users need to explicitly set the minReadySeconds parameter in the StatefulSet spec i.e `.spec.minReadySeconds` field.
If the feature is disabled the field is preserved. If it was already set in the persisted StatefulSet object, otherwise it is silently dropped.

###### What specific metrics should inform a rollback?

<!--
What signals should users be paying attention to when the feature is young
that might indicate a serious problem?
-->
We have a metric called `kube_statefulset_status_replicas_available`
which we added recently to track the number of available replicas. The cluster-admin could use
this metric to track the problems. If the value is immediately equal to the value of `Ready` replicas or if it is `0`, it can be considered as a feature failure.

###### Were upgrade and rollback tested? Was the upgrade->downgrade->upgrade path tested?
Manually tested. No issues were found when we enabled the feature gate -> disabled it ->
re-enabled the feature gate. Upgrade -> downgrade -> upgrade scenario has been manually tested.
<!--
Describe manual testing that was done and the outcomes.
Longer term, we may want to require automated upgrade/rollback tests, but we
are missing a bunch of machinery and tooling and can't do that now.
-->

###### Is the rollout accompanied by any deprecations and/or removals of features, APIs, fields of API types, flags, etc.?

<!--
Even if applying deprecation policies, they may still surprise some users.
-->
None
### Monitoring Requirements

<!--
This section must be completed when targeting beta to a release.
-->

###### How can an operator determine if the feature is in use by workloads?

<!--
Ideally, this should be a metric. Operations against the Kubernetes API (e.g.,
checking if there are objects with field X set) may be a last resort. Avoid
logs or events for this purpose.
-->
By checking the `kube_statefulset_status_replicas_available` metric. If all the `Ready` replicas are accounted for in `kube_statefulset_status_replicas_available` after waiting for `minReadySeconds`, we can consider the feature to be in use by workloads.

###### What are the SLIs (Service Level Indicators) an operator can use to determine the health of the service?

<!--
Pick one more of these and delete the rest.
-->

- [x] Metrics
  - Metric name: `kube_statefulset_status_replicas_available`
  - [Optional] Aggregation method:
  - Components exposing the metric: kube-controller-manager via kube_state_metrics. [PR which adds the metric](https://github.com/kubernetes/kube-state-metrics/pull/1532)

The `kube_statefulset_status_replicas_available` gives the number of replicas available. Since the
`kube_statefulset_status_replicas_available` metric tracks available replicas, comparing it with `kube_statefulset_status_replicas_ready` metric should give us an understanding of the health of the feature. There should be certain times where `kube_statefulset_status_replicas_available` lags behind `kube_statefulset_status_replicas_ready` for a duration of minReadySeconds. This lag defines the correctness of the functionality.

###### What are the reasonable SLOs (Service Level Objectives) for the above SLIs?

<!--
At a high level, this usually will be in the form of "high percentile of SLI
per day <= X". It's impossible to provide comprehensive guidance, but at the very
high level (needs more precise definitions) those may be things like:
  - per-day percentage of API calls finishing with 5XX errors <= 1%
  - 99% percentile over day of absolute value from (job creation time minus expected
    job creation time) for cron job <= 10%
  - 99,9% of /health requests per day finish with 200 code
-->
All the `Available` pods created should be more than the time specified in `.spec.minReadySeconds` 99% of the time. 

###### Are there any missing metrics that would be useful to have to improve observability of this feature?

<!--
Describe the metrics themselves and the reasons why they weren't added (e.g., cost,
implementation difficulties, etc.).
-->

### Dependencies

<!--
This section must be completed when targeting beta to a release.
-->

###### Does this feature depend on any specific services running in the cluster?

<!--
Think about both cluster-level services (e.g. metrics-server) as well
as node-level agents (e.g. specific version of CRI). Focus on external or
optional services that are needed. For example, if this feature depends on
a cloud provider API, or upon an external software-defined storage or network
control plane.

For each of these, fill in the following—thinking about running existing user workloads
and creating new ones, as well as about cluster-level services (e.g. DNS):
  - [Dependency name]
    - Usage description:
      - Impact of its outage on the feature:
      - Impact of its degraded performance or high-error rates on the feature:
-->
None. It is part of the StatefulSet controller.

### Scalability

<!--
For alpha, this section is encouraged: reviewers should consider these questions
and attempt to answer them.

For beta, this section is required: reviewers must answer these questions.

For GA, this section is required: approvers should be able to confirm the
previous answers based on experience in the field.
-->

###### Will enabling / using this feature result in any new API calls?
No.
<!--
Describe them, providing:
  - API call type (e.g. PATCH pods)
  - estimated throughput
  - originating component(s) (e.g. Kubelet, Feature-X-controller)
Focusing mostly on:
  - components listing and/or watching resources they didn't before
  - API calls that may be triggered by changes of some Kubernetes resources
    (e.g. update of object X triggers new updates of object Y)
  - periodic API calls to reconcile state (e.g. periodic fetching state,
    heartbeats, leader election, etc.)
-->

###### Will enabling / using this feature result in introducing new API types?
No.
<!--
Describe them, providing:
  - API type
  - Supported number of objects per cluster
  - Supported number of objects per namespace (for namespace-scoped objects)
-->

###### Will enabling / using this feature result in any new calls to the cloud provider?
No.
<!--
Describe them, providing:
  - Which API(s):
  - Estimated increase:
-->

###### Will enabling / using this feature result in increasing size or count of the existing API objects?
Yes.
API type(s): StatefulSet
  - Estimated increase in size: 
    - New field in StatefulSet spec about 4 bytes
    - New field in StatefulSet status about 4 bytes
  
<!--
Describe them, providing:
  - API type(s):
  - Estimated increase in size: (e.g., new annotation of size 32B)
  - Estimated amount of new objects: (e.g., new Object X for every existing Pod)
-->

###### Will enabling / using this feature result in increasing time taken by any operations covered by existing SLIs/SLOs?

No.
<!--
Look at the [existing SLIs/SLOs].

Think about adding additional work or introducing new steps in between
(e.g. need to do X to start a container), etc. Please describe the details.

[existing SLIs/SLOs]: https://git.k8s.io/community/sig-scalability/slos/slos.md#kubernetes-slisslos
-->

###### Will enabling / using this feature result in non-negligible increase of resource usage (CPU, RAM, disk, IO, ...) in any components?

<!--
Things to keep in mind include: additional in-memory state, additional
non-trivial computations, excessive access to disks (including increased log
volume), significant amount of data sent and/or received over network, etc.
This through this both in small and large cases, again with respect to the
[supported limits].

[supported limits]: https://git.k8s.io/community//sig-scalability/configs-and-limits/thresholds.md
-->
No.

### Troubleshooting

<!--
This section must be completed when targeting beta to a release.

The Troubleshooting section currently serves the `Playbook` role. We may consider
splitting it into a dedicated `Playbook` document (potentially with some monitoring
details). For now, we leave it here.
-->

###### How does this feature react if the API server and/or etcd is unavailable?

The controller won't be able to make progress, all currently queued resources are re-queued. This feature does not change current behavior of the controller in this regard.

###### What are other known failure modes?

<!--
For each of them, fill in the following information by copying the below template:
  - [Failure mode brief description]
    - Detection: How can it be detected via metrics? Stated another way:
      how can an operator troubleshoot without logging into a master or worker node?
    - Mitigations: What can be done to stop the bleeding, especially for already
      running user workloads?
    - Diagnostics: What are the useful log messages and their required logging
      levels that could help debug the issue?
      Not required until feature graduated to beta.
    - Testing: Are there any tests for failure mode? If not, describe why.
-->
 - `minReadySeconds` not respected and all the pods are shown `Available` immediately
    - Detection: Looking at `kube_statefulset_status_replicas_available` metric
    - Mitigations: Disable the `StatefulSetMinReadySeconds` feature flag
    - Diagnostics: Controller-manager when starting at log-level 4 and above
    - Testing: Yes, e2e tests are already in place
  - `minReadySeconds` not respected and none of the pods are shown as `Available` after `minReadySeconds`
    - Detection: Looking at `kube_statefulset_status_replicas_available`. None of the pods will be shown available
    - Mitigations: Disable the `StatefulSetMinReadySeconds` feature flag
    - Diagnostics: Controller-manager when starting at log-level 4 and above
    - Testing: Yes, e2e tests are already in place

###### What steps should be taken if SLOs are not being met to determine the problem?

## Implementation History
- 2021-04-29: Initial KEP merged
- 2021-06-15: Initial implementation PR merged
- 2021-07-14: Graduate the feature to Beta proposed 
<!--
Major milestones in the lifecycle of a KEP should be tracked in this section.
Major milestones might include:
- the `Summary` and `Motivation` sections being merged, signaling SIG acceptance
- the `Proposal` section being merged, signaling agreement on a proposed design
- the date implementation started
- the first Kubernetes release where an initial version of the KEP was available
- the version of Kubernetes where the KEP graduated to general availability
- when the KEP was retired or superseded
-->

## Drawbacks
Adds more complexity to StatefulSet controller in terms of checking Pod availability for a certain amount of time.
Measuring the availability may be hard as there can be clock skew between Master/node.
However we have successfully implemented this feature in Deployment and DaemonSet controllers.
<!--
Why should this KEP _not_ be implemented?
-->

## Alternatives
Use increased `readinessProbe` and `initialDelaySeconds` to pod spec. This is not always fool proof and can cause problems
<!--
What other approaches did you consider, and why did you rule them out? These do
not need to be as detailed as the proposal, but should include enough
information to express the idea and why it was not acceptable.
-->

## Infrastructure Needed (Optional)

<!--
Use this section if you need things from the project/SIG. Examples include a
new subproject, repos requested, or GitHub details. Listing these here allows a
SIG to get the process for these resources started right away.
-->
